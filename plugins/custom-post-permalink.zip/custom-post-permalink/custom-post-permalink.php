<?php
/**
 * Plugin Name: Custom Post Permalink
 * Description: Allows selected post types to use a custom permalink path instead of their default permalink.
 * Version: 1.0.0
 * Author: shimanta das te
 */

if (!defined('ABSPATH')) {
    exit;
}


/*
|--------------------------------------------------------------------------
| 1. ADMIN MENU
|--------------------------------------------------------------------------
*/

add_action('admin_menu', 'cpp_add_settings_page');

function cpp_add_settings_page() {

    add_options_page(
        'Custom Post Permalink',
        'Custom Post Permalink',
        'manage_options',
        'custom-post-permalink',
        'cpp_settings_page'
    );
}


/*
|--------------------------------------------------------------------------
| 2. SETTINGS PAGE
|--------------------------------------------------------------------------
*/

function cpp_settings_page() {

    if (!current_user_can('manage_options')) {
        return;
    }


    /*
    |--------------------------------------------------------------------------
    | SAVE SETTINGS
    |--------------------------------------------------------------------------
    */

    if (
        isset($_POST['cpp_save_settings']) &&
        check_admin_referer(
            'cpp_save_settings_action',
            'cpp_nonce'
        )
    ) {

        $settings = array();

        if (
            isset($_POST['cpp_post_types']) &&
            is_array($_POST['cpp_post_types'])
        ) {

            foreach (
                $_POST['cpp_post_types'] as $post_type => $meta_key
            ) {

                /*
                 * Only save enabled post types
                 */
                if (
                    !isset($_POST['cpp_enabled'][$post_type])
                ) {
                    continue;
                }

                $post_type = sanitize_key(
                    $post_type
                );

                $meta_key = sanitize_key(
                    wp_unslash($meta_key)
                );

                if (!empty($meta_key)) {

                    $settings[$post_type] = $meta_key;
                }
            }
        }


        update_option(
            'cpp_post_type_settings',
            $settings
        );


        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>Custom permalink settings saved.</p>';
        echo '</div>';
    }


    /*
    |--------------------------------------------------------------------------
    | GET POST TYPES
    |--------------------------------------------------------------------------
    */

    $post_types = get_post_types(
        array(
            'show_ui' => true,
        ),
        'objects'
    );


    /*
    |--------------------------------------------------------------------------
    | GET SAVED SETTINGS
    |--------------------------------------------------------------------------
    */

    $saved_settings = get_option(
        'cpp_post_type_settings',
        array()
    );

    ?>

    <div class="wrap">

        <h1>Custom Post Permalink</h1>

        <p>
            Select the post types where you want to enable
            custom permalink paths.
        </p>

        <form method="post">

            <?php

            wp_nonce_field(
                'cpp_save_settings_action',
                'cpp_nonce'
            );

            ?>

            <table class="widefat striped">

                <thead>

                    <tr>

                        <th>
                            Post Type
                        </th>

                        <th>
                            Enable
                        </th>

                        <th>
                            Meta Key
                        </th>

                    </tr>

                </thead>

                <tbody>

                    <?php foreach (
                        $post_types as $post_type => $post_type_object
                    ) : ?>

                        <?php

                        /*
                         * Skip attachments
                         */
                        if (
                            $post_type === 'attachment'
                        ) {
                            continue;
                        }


                        $enabled = false;

                        $meta_key = '';


                        if (
                            isset(
                                $saved_settings[$post_type]
                            )
                        ) {

                            $enabled = true;

                            $meta_key =
                                $saved_settings[$post_type];
                        }

                        ?>

                        <tr>

                            <td>

                                <strong>

                                    <?php

                                    echo esc_html(
                                        $post_type_object
                                            ->labels
                                            ->name
                                    );

                                    ?>

                                </strong>

                                <br>

                                <code>

                                    <?php

                                    echo esc_html(
                                        $post_type
                                    );

                                    ?>

                                </code>

                            </td>


                            <td>

                                <label>

                                    <input
                                        type="checkbox"
                                        name="cpp_enabled[<?php echo esc_attr($post_type); ?>]"
                                        value="1"

                                        <?php

                                        checked(
                                            $enabled,
                                            true
                                        );

                                        ?>

                                    >

                                    Enable

                                </label>

                            </td>


                            <td>

                                <input
                                    type="text"
                                    name="cpp_post_types[<?php echo esc_attr($post_type); ?>]"
                                    value="<?php echo esc_attr($meta_key); ?>"
                                    placeholder="_custom_permalink"
                                    style="width: 400px;"
                                >

                                <p class="description">

                                    Example:

                                    <code>
                                        _custom_permalink
                                    </code>

                                </p>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>


            <p>

                <button
                    type="submit"
                    name="cpp_save_settings"
                    class="button button-primary"
                >

                    Save Settings

                </button>

            </p>

        </form>

    </div>

    <?php
}


/*
|--------------------------------------------------------------------------
| 3. ADD CUSTOM PERMALINK FIELD
|--------------------------------------------------------------------------
*/

add_action(
    'edit_form_after_title',
    'cpp_add_permalink_field'
);

function cpp_add_permalink_field($post) {

    /*
     * Get settings
     */
    $settings = get_option(
        'cpp_post_type_settings',
        array()
    );


    /*
     * Check if this post type is enabled
     */
    if (
        empty(
            $settings[$post->post_type]
        )
    ) {
        return;
    }


    /*
     * Get meta key
     */
    $meta_key =
        $settings[$post->post_type];


    /*
     * Get current custom permalink
     */
    $custom_permalink =
        get_post_meta(
            $post->ID,
            $meta_key,
            true
        );

    ?>

    <div
        style="
            margin: 15px 0;
            padding: 15px;
            border: 1px solid #ccd0d4;
            background: #fff;
        "
    >

        <label>

            <strong>
                Custom Permalink
            </strong>

        </label>


        <input
            type="text"
            name="cpp_custom_permalink"
            value="<?php echo esc_attr(
                $custom_permalink
            ); ?>"
            placeholder="/developer/wordpress/"
            style="
                width: 100%;
                margin-top: 5px;
            "
        >


        <p class="description">

            Enter the complete relative permalink path.

            Example:

            <code>
                /developer/wordpress/
            </code>

            <br>

            This will replace the default permalink
            for this post.

        </p>

    </div>

    <?php
}


/*
|--------------------------------------------------------------------------
| 4. SAVE CUSTOM PERMALINK
|--------------------------------------------------------------------------
*/

add_action(
    'save_post',
    'cpp_save_custom_permalink'
);

function cpp_save_custom_permalink($post_id) {

    /*
     * Don't run during autosave
     */
    if (
        defined('DOING_AUTOSAVE') &&
        DOING_AUTOSAVE
    ) {
        return;
    }


    /*
     * Don't run revisions
     */
    if (
        wp_is_post_revision(
            $post_id
        )
    ) {
        return;
    }


    /*
     * Check permission
     */
    if (
        !current_user_can(
            'edit_post',
            $post_id
        )
    ) {
        return;
    }


    /*
     * Get post type
     */
    $post_type =
        get_post_type(
            $post_id
        );


    /*
     * Get settings
     */
    $settings =
        get_option(
            'cpp_post_type_settings',
            array()
        );


    /*
     * Check if enabled
     */
    if (
        empty(
            $settings[$post_type]
        )
    ) {
        return;
    }


    /*
     * Get meta key
     */
    $meta_key =
        $settings[$post_type];


    /*
     * Check submitted value
     */
    if (
        !isset(
            $_POST['cpp_custom_permalink']
        )
    ) {
        return;
    }


    /*
     * Sanitize
     */
    $custom_path =
        sanitize_text_field(
            wp_unslash(
                $_POST['cpp_custom_permalink']
            )
        );


    /*
     * Empty value
     *
     * Remove custom permalink
     */
    if (
        empty($custom_path)
    ) {

        delete_post_meta(
            $post_id,
            $meta_key
        );

        return;
    }


    /*
     * Make sure path starts with /
     */
    if (
        strpos(
            $custom_path,
            '/'
        ) !== 0
    ) {

        $custom_path =
            '/' . $custom_path;
    }


    /*
     * Remove duplicate slashes
     */
    $custom_path =
        preg_replace(
            '#/+#',
            '/',
            $custom_path
        );


    /*
     * Always end with /
     */
    $custom_path =
        trailingslashit(
            $custom_path
        );


    /*
     * Get source post permalink
     */
    $current_permalink =
        get_permalink(
            $post_id
        );


    /*
     * Build new URL
     */
    $new_permalink =
        home_url(
            $custom_path
        );


    /*
     * Prevent same URL
     */
    if (
        untrailingslashit(
            $current_permalink
        ) ===
        untrailingslashit(
            $new_permalink
        )
    ) {

        update_post_meta(
            $post_id,
            $meta_key,
            $custom_path
        );

        return;
    }


    /*
     * Check URL conflict
     */
    $conflict_post_id =
        cpp_find_post_by_custom_permalink(
            $custom_path,
            $post_id
        );


    if (
        $conflict_post_id
    ) {

        add_filter(
            'redirect_post_location',
            function($location) {

                return add_query_arg(
                    'cpp_error',
                    'url_exists',
                    $location
                );

            }
        );

        return;
    }


    /*
     * Save custom permalink
     */
    update_post_meta(
        $post_id,
        $meta_key,
        $custom_path
    );


    /*
     * Flush rewrite rules
     */
    flush_rewrite_rules(false);
}


/*
|--------------------------------------------------------------------------
| 5. CHECK CUSTOM PERMALINK CONFLICT
|--------------------------------------------------------------------------
*/

function cpp_find_post_by_custom_permalink(
    $custom_path,
    $exclude_post_id = 0
) {

    /*
     * Get all configured post types
     */
    $settings =
        get_option(
            'cpp_post_type_settings',
            array()
        );


    if (
        empty($settings)
    ) {
        return false;
    }


    /*
     * Search each configured post type
     */
    foreach (
        $settings as $post_type => $meta_key
    ) {

        $query =
            new WP_Query(
                array(
                    'post_type'      => $post_type,
                    'post_status'    => array(
                        'publish',
                        'draft',
                        'pending',
                        'private',
                    ),
                    'posts_per_page' => 1,

                    'post__not_in'   => array(
                        $exclude_post_id
                    ),

                    'meta_query'     => array(
                        array(
                            'key'     => $meta_key,
                            'value'   => $custom_path,
                            'compare' => '=',
                        ),
                    ),
                )
            );


        if (
            $query->have_posts()
        ) {

            return $query->posts[0]->ID;
        }
    }


    return false;
}


/*
|--------------------------------------------------------------------------
| 6. CHANGE POST PERMALINK
|--------------------------------------------------------------------------
*/

add_filter(
    'post_type_link',
    'cpp_custom_post_permalink',
    10,
    2
);

function cpp_custom_post_permalink(
    $post_link,
    $post
) {

    /*
     * Get settings
     */
    $settings =
        get_option(
            'cpp_post_type_settings',
            array()
        );


    /*
     * Check post type
     */
    if (
        empty(
            $settings[$post->post_type]
        )
    ) {
        return $post_link;
    }


    /*
     * Get meta key
     */
    $meta_key =
        $settings[$post->post_type];


    /*
     * Get custom permalink
     */
    $custom_path =
        get_post_meta(
            $post->ID,
            $meta_key,
            true
        );


    /*
     * No custom permalink
     */
    if (
        empty($custom_path)
    ) {
        return $post_link;
    }


    /*
     * Return custom URL
     */
    return home_url(
        ltrim(
            $custom_path,
            '/'
        )
    );
}


/*
|--------------------------------------------------------------------------
| 7. LOAD POST USING CUSTOM PERMALINK
|--------------------------------------------------------------------------
*/

add_action(
    'parse_request',
    'cpp_load_custom_permalink'
);

function cpp_load_custom_permalink(
    $wp
) {

    /*
     * Get requested path
     */
    $request_path =
        trim(
            $wp->request,
            '/'
        );


    /*
     * Nothing requested
     */
    if (
        empty($request_path)
    ) {
        return;
    }


    /*
     * Get settings
     */
    $settings =
        get_option(
            'cpp_post_type_settings',
            array()
        );


    if (
        empty($settings)
    ) {
        return;
    }


    /*
     * Search custom permalink
     */
    foreach (
        $settings as $post_type => $meta_key
    ) {

        $posts =
            get_posts(
                array(
                    'post_type'      => $post_type,
                    'post_status'    => 'publish',
                    'posts_per_page' => 1,

                    'meta_query'     => array(
                        array(
                            'key'     => $meta_key,
                            'value'   => '/' .
                                $request_path .
                                '/',
                            'compare' => '=',
                        ),
                    ),
                )
            );


        /*
         * Found post
         */
        if (
            !empty($posts)
        ) {

            $post =
                $posts[0];


            /*
             * Tell WordPress to load
             * this post
             */
            $wp->query_vars =
                array(
                    'p'         => $post->ID,
                    'post_type' => $post_type,
                );


            return;
        }
    }
}


/*
|--------------------------------------------------------------------------
| 8. ADMIN ERROR MESSAGE
|--------------------------------------------------------------------------
*/

add_action(
    'admin_notices',
    'cpp_admin_error_notice'
);

function cpp_admin_error_notice() {

    if (
        !isset(
            $_GET['cpp_error']
        )
    ) {
        return;
    }


    if (
        $_GET['cpp_error'] ===
        'url_exists'
    ) {

        echo '
        <div class="notice notice-error is-dismissible">
            <p>
                <strong>
                    Custom Post Permalink:
                </strong>
                This permalink is already assigned
                to another post. Please choose
                a different URL.
            </p>
        </div>
        ';
    }
}
?>