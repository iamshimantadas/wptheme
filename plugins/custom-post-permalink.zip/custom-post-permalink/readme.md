# Custom Post permalink manager
This aims to manage permalink against posttype. 
for perticular post we can assign that. 

ex:
if configured in post, http://localhost/project1/services/mobile-repair/ => http://localhost/developer/shopify

if not, 
http://localhost/project1/services/mobile-repair/ => auto restore.
