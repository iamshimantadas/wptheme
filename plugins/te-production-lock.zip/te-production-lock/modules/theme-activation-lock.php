<?php
/**
 * TE Production Lock
 *
 * Module: Theme Lock
 *
 * Prevents selected WordPress user roles from:
 * - Activating themes
 * - Switching themes
 * - Adding/installing themes
 * - Uploading themes
 * - Deleting themes
 * - Live Preview / Customizer
 * - Editing themes
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/**
 * Roles that are NOT allowed to perform theme operations.
 *
 * Add or remove roles here as needed.
 */
function te_theme_activation_locked_roles() {

    return array(
        'administrator',
        'editor',
        'author',
        'contributor',
        'subscriber',
    );
}


/**
 * Check if current user is locked.
 */
function te_is_theme_locked_user() {

    $user = wp_get_current_user();

    if ( ! $user || empty( $user->roles ) ) {
        return false;
    }

    $locked_roles = te_theme_activation_locked_roles();

    return ! empty(
        array_intersect(
            (array) $user->roles,
            $locked_roles
        )
    );
}


/**
 * ---------------------------------------------------------
 * 1. BLOCK THEME ACTIVATION / SWITCHING
 * ---------------------------------------------------------
 */
add_action( 'admin_init', 'te_block_theme_activation', 1 );

function te_block_theme_activation() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! te_is_theme_locked_user() ) {
        return;
    }

    if (
        isset( $_GET['action'] ) &&
        'activate' === $_GET['action'] &&
        isset( $_GET['stylesheet'] )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'te_theme_activation_blocked',
                '1',
                admin_url( 'themes.php' )
            )
        );

        exit;
    }
}


/**
 * ---------------------------------------------------------
 * 2. BLOCK THEME DELETE
 * ---------------------------------------------------------
 */
add_action( 'admin_init', 'te_block_theme_delete', 1 );

function te_block_theme_delete() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! te_is_theme_locked_user() ) {
        return;
    }

    if (
        isset( $_GET['action'] ) &&
        'delete' === $_GET['action'] &&
        isset( $_GET['stylesheet'] )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'te_theme_delete_blocked',
                '1',
                admin_url( 'themes.php' )
            )
        );

        exit;
    }
}


/**
 * ---------------------------------------------------------
 * 3. BLOCK THEME INSTALL / ADD NEW
 * ---------------------------------------------------------
 */
add_action( 'admin_init', 'te_block_theme_install', 1 );

function te_block_theme_install() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! te_is_theme_locked_user() ) {
        return;
    }

    // Block theme installation page.
    if (
        isset( $_GET['page'] ) &&
        'theme-install.php' === $_GET['page']
    ) {

        wp_safe_redirect(
            add_query_arg(
                'te_theme_install_blocked',
                '1',
                admin_url( 'themes.php' )
            )
        );

        exit;
    }

    // Block direct theme-install.php access.
    global $pagenow;

    if ( 'theme-install.php' === $pagenow ) {

        wp_safe_redirect(
            add_query_arg(
                'te_theme_install_blocked',
                '1',
                admin_url( 'themes.php' )
            )
        );

        exit;
    }
}


/**
 * ---------------------------------------------------------
 * 4. BLOCK THEME UPLOAD
 * ---------------------------------------------------------
 */
add_action( 'admin_init', 'te_block_theme_upload', 1 );

function te_block_theme_upload() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! te_is_theme_locked_user() ) {
        return;
    }

    global $pagenow;

    if (
        'update.php' === $pagenow &&
        isset( $_POST['action'] ) &&
        'upload-theme' === $_POST['action']
    ) {

        wp_die(
            esc_html__(
                'Theme upload is disabled by TE Production Lock.',
                'te-production-lock'
            ),
            esc_html__( 'Theme Upload Blocked', 'te-production-lock' ),
            array(
                'response' => 403,
                'back_link' => true,
            )
        );
    }
}


/**
 * ---------------------------------------------------------
 * 5. BLOCK LIVE PREVIEW / CUSTOMIZER
 * ---------------------------------------------------------
 */
add_action( 'customize_controls_init', 'te_block_theme_customizer' );

function te_block_theme_customizer() {

    if ( ! te_is_theme_locked_user() ) {
        return;
    }

    wp_die(
        esc_html__(
            'Theme Live Preview and Customizer are disabled by TE Production Lock.',
            'te-production-lock'
        ),
        esc_html__( 'Theme Preview Blocked', 'te-production-lock' ),
        array(
            'response' => 403,
            'back_link' => true,
        )
    );
}


/**
 * ---------------------------------------------------------
 * 6. BLOCK THEME EDITOR
 * ---------------------------------------------------------
 */
add_action( 'admin_init', 'te_block_theme_editor', 1 );

function te_block_theme_editor() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! te_is_theme_locked_user() ) {
        return;
    }

    global $pagenow;

    if ( 'theme-editor.php' === $pagenow ) {

        wp_safe_redirect(
            add_query_arg(
                'te_theme_editor_blocked',
                '1',
                admin_url( 'themes.php' )
            )
        );

        exit;
    }
}


/**
 * ---------------------------------------------------------
 * 7. HIDE "ADD NEW" BUTTON
 * ---------------------------------------------------------
 */
add_action( 'admin_head-themes.php', 'te_hide_add_new_theme_button' );

function te_hide_add_new_theme_button() {

    if ( ! te_is_theme_locked_user() ) {
        return;
    }

    ?>
    <style>
        .page-title-action,
        .theme-install,
        .theme-install-button,
        .more-details {
            display: none !important;
        }
    </style>
    <?php
}


/**
 * ---------------------------------------------------------
 * 8. HIDE THEME DELETE LINK
 * ---------------------------------------------------------
 */
add_action( 'admin_head-themes.php', 'te_hide_theme_delete_link' );

function te_hide_theme_delete_link() {

    if ( ! te_is_theme_locked_user() ) {
        return;
    }

    ?>
    <style>
        .delete-theme {
            display: none !important;
        }
    </style>
    <?php
}


/**
 * ---------------------------------------------------------
 * 9. HIDE LIVE PREVIEW BUTTON
 * ---------------------------------------------------------
 */
add_action( 'admin_head-themes.php', 'te_hide_theme_preview_button' );

function te_hide_theme_preview_button() {

    if ( ! te_is_theme_locked_user() ) {
        return;
    }

    ?>
    <style>
        .load-customize,
        .customize-theme,
        .theme-customize {
            display: none !important;
        }
    </style>
    <?php
}


/**
 * ---------------------------------------------------------
 * 10. ADMIN NOTICES
 * ---------------------------------------------------------
 */
add_action( 'admin_notices', 'te_theme_lock_admin_notice' );

function te_theme_lock_admin_notice() {

    $screen = get_current_screen();

    if ( ! $screen || 'themes' !== $screen->id ) {
        return;
    }

    $notice = '';

    if (
        isset( $_GET['te_theme_activation_blocked'] ) &&
        '1' === $_GET['te_theme_activation_blocked']
    ) {

        $notice = 'Theme activation and switching are disabled.';
    }

    elseif (
        isset( $_GET['te_theme_delete_blocked'] ) &&
        '1' === $_GET['te_theme_delete_blocked']
    ) {

        $notice = 'Theme deletion is disabled.';
    }

    elseif (
        isset( $_GET['te_theme_install_blocked'] ) &&
        '1' === $_GET['te_theme_install_blocked']
    ) {

        $notice = 'Adding and installing new themes are disabled.';
    }

    elseif (
        isset( $_GET['te_theme_editor_blocked'] ) &&
        '1' === $_GET['te_theme_editor_blocked']
    ) {

        $notice = 'Theme editing is disabled.';
    }

    if ( ! empty( $notice ) ) {
        ?>
        <div class="notice notice-error is-dismissible">
            <p>
                <strong>TE Production Lock:</strong>
                <?php echo esc_html( $notice ); ?>
                Please contact the site administrator.
            </p>
        </div>
        <?php
    }
}
?>