<?php
/**
 * TE Production Lock
 *
 * Module: Plugin Lock
 *
 * Prevents selected WordPress user roles from:
 *
 * - Activating plugins
 * - Deactivating plugins
 * - Deleting plugins
 * - Installing plugins
 * - Uploading plugins
 * - Editing plugins
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/**
 * Roles that are NOT allowed to perform plugin operations.
 *
 * Add or remove roles here as needed.
 */
function te_plugin_locked_roles() {

    return array(
        'administrator',
        'editor',
        'author',
        'contributor',
        'subscriber',
    );
}


/**
 * Check if current user is a locked plugin user.
 */
function te_is_plugin_locked_user() {

    $user = wp_get_current_user();

    if ( ! $user || empty( $user->roles ) ) {
        return false;
    }

    $locked_roles = te_plugin_locked_roles();

    return ! empty(
        array_intersect(
            (array) $user->roles,
            $locked_roles
        )
    );
}


/**
 * ---------------------------------------------------------
 * 1. BLOCK PLUGIN ACTIVATION
 * ---------------------------------------------------------
 */
add_action( 'admin_init', 'te_block_plugin_activation', 1 );

function te_block_plugin_activation() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! te_is_plugin_locked_user() ) {
        return;
    }

    if (
        isset( $_GET['action'] ) &&
        'activate' === $_GET['action'] &&
        isset( $_GET['plugin'] )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'te_plugin_activation_blocked',
                '1',
                admin_url( 'plugins.php' )
            )
        );

        exit;
    }
}


/**
 * ---------------------------------------------------------
 * 2. BLOCK PLUGIN DEACTIVATION
 * ---------------------------------------------------------
 */
add_action( 'admin_init', 'te_block_plugin_deactivation', 1 );

function te_block_plugin_deactivation() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! te_is_plugin_locked_user() ) {
        return;
    }

    if (
        isset( $_GET['action'] ) &&
        'deactivate' === $_GET['action'] &&
        isset( $_GET['plugin'] )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'te_plugin_deactivation_blocked',
                '1',
                admin_url( 'plugins.php' )
            )
        );

        exit;
    }
}


/**
 * ---------------------------------------------------------
 * 3. BLOCK PLUGIN DELETE
 * ---------------------------------------------------------
 */
add_action( 'admin_init', 'te_block_plugin_delete', 1 );

function te_block_plugin_delete() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! te_is_plugin_locked_user() ) {
        return;
    }

    if (
        isset( $_GET['action'] ) &&
        'delete-selected' === $_GET['action']
    ) {

        wp_safe_redirect(
            add_query_arg(
                'te_plugin_delete_blocked',
                '1',
                admin_url( 'plugins.php' )
            )
        );

        exit;
    }

    // Also block direct delete-plugin.php requests.
    global $pagenow;

    if (
        'delete-plugin.php' === $pagenow &&
        isset( $_REQUEST['plugin'] )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'te_plugin_delete_blocked',
                '1',
                admin_url( 'plugins.php' )
            )
        );

        exit;
    }
}


/**
 * ---------------------------------------------------------
 * 4. BLOCK PLUGIN INSTALLATION
 * ---------------------------------------------------------
 */
add_action( 'admin_init', 'te_block_plugin_install', 1 );

function te_block_plugin_install() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! te_is_plugin_locked_user() ) {
        return;
    }

    global $pagenow;

    // Block plugin-install.php.
    if ( 'plugin-install.php' === $pagenow ) {

        wp_safe_redirect(
            add_query_arg(
                'te_plugin_install_blocked',
                '1',
                admin_url( 'plugins.php' )
            )
        );

        exit;
    }
}


/**
 * ---------------------------------------------------------
 * 5. BLOCK PLUGIN UPLOAD
 * ---------------------------------------------------------
 */
add_action( 'admin_init', 'te_block_plugin_upload', 1 );

function te_block_plugin_upload() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! te_is_plugin_locked_user() ) {
        return;
    }

    global $pagenow;

    // WordPress uses update.php for plugin uploads.
    if (
        'update.php' === $pagenow &&
        isset( $_POST['action'] ) &&
        'upload-plugin' === $_POST['action']
    ) {

        wp_die(
            esc_html__(
                'Plugin upload is disabled by TE Production Lock.',
                'te-production-lock'
            ),
            esc_html__(
                'Plugin Upload Blocked',
                'te-production-lock'
            ),
            array(
                'response'  => 403,
                'back_link' => true,
            )
        );
    }
}


/**
 * ---------------------------------------------------------
 * 6. BLOCK PLUGIN EDITOR
 * ---------------------------------------------------------
 */
add_action( 'admin_init', 'te_block_plugin_editor', 1 );

function te_block_plugin_editor() {

    if ( ! is_admin() ) {
        return;
    }

    if ( ! te_is_plugin_locked_user() ) {
        return;
    }

    global $pagenow;

    if ( 'plugin-editor.php' === $pagenow ) {

        wp_safe_redirect(
            add_query_arg(
                'te_plugin_editor_blocked',
                '1',
                admin_url( 'plugins.php' )
            )
        );

        exit;
    }
}


/**
 * ---------------------------------------------------------
 * 7. HIDE "ADD NEW" PLUGIN BUTTON
 * ---------------------------------------------------------
 */
add_action( 'admin_head-plugins.php', 'te_hide_add_new_plugin_button' );

function te_hide_add_new_plugin_button() {

    if ( ! te_is_plugin_locked_user() ) {
        return;
    }

    ?>
    <style>
        .page-title-action {
            display: none !important;
        }
    </style>
    <?php
}


/**
 * ---------------------------------------------------------
 * 8. HIDE PLUGIN ACTIVATION / DEACTIVATION LINKS
 * ---------------------------------------------------------
 */
add_filter(
    'plugin_action_links',
    'te_hide_plugin_action_links',
    10,
    4
);

function te_hide_plugin_action_links(
    $actions,
    $plugin_file,
    $plugin_data,
    $context
) {

    if ( ! te_is_plugin_locked_user() ) {
        return $actions;
    }

    // Remove Activate.
    unset( $actions['activate'] );

    // Remove Deactivate.
    unset( $actions['deactivate'] );

    // Remove Delete.
    unset( $actions['delete'] );

    // Remove Edit.
    unset( $actions['edit'] );

    return $actions;
}


/**
 * ---------------------------------------------------------
 * 9. HIDE BULK ACTIONS
 * ---------------------------------------------------------
 */
add_filter(
    'bulk_actions-plugins',
    'te_remove_plugin_bulk_actions'
);

function te_remove_plugin_bulk_actions( $actions ) {

    if ( ! te_is_plugin_locked_user() ) {
        return $actions;
    }

    unset( $actions['activate-selected'] );
    unset( $actions['deactivate-selected'] );
    unset( $actions['delete-selected'] );

    return $actions;
}


/**
 * ---------------------------------------------------------
 * 10. HIDE "ADD NEW" FROM ADMIN MENU
 * ---------------------------------------------------------
 */
add_action( 'admin_menu', 'te_remove_plugin_install_menu', 999 );

function te_remove_plugin_install_menu() {

    if ( ! te_is_plugin_locked_user() ) {
        return;
    }

    remove_submenu_page(
        'plugins.php',
        'plugin-install.php'
    );
}


/**
 * ---------------------------------------------------------
 * 11. HIDE PLUGIN EDITOR FROM TOOLS
 * ---------------------------------------------------------
 */
add_action( 'admin_menu', 'te_remove_plugin_editor_menu', 999 );

function te_remove_plugin_editor_menu() {

    if ( ! te_is_plugin_locked_user() ) {
        return;
    }

    remove_submenu_page(
        'plugins.php',
        'plugin-editor.php'
    );
}


/**
 * ---------------------------------------------------------
 * 12. ADMIN NOTICE
 * ---------------------------------------------------------
 */
add_action( 'admin_notices', 'te_plugin_lock_admin_notice' );

function te_plugin_lock_admin_notice() {

    $screen = get_current_screen();

    if ( ! $screen || 'plugins' !== $screen->id ) {
        return;
    }

    $notice = '';

    if (
        isset( $_GET['te_plugin_activation_blocked'] ) &&
        '1' === $_GET['te_plugin_activation_blocked']
    ) {

        $notice = 'Plugin activation is disabled.';
    }

    elseif (
        isset( $_GET['te_plugin_deactivation_blocked'] ) &&
        '1' === $_GET['te_plugin_deactivation_blocked']
    ) {

        $notice = 'Plugin deactivation is disabled.';
    }

    elseif (
        isset( $_GET['te_plugin_delete_blocked'] ) &&
        '1' === $_GET['te_plugin_delete_blocked']
    ) {

        $notice = 'Plugin deletion is disabled.';
    }

    elseif (
        isset( $_GET['te_plugin_install_blocked'] ) &&
        '1' === $_GET['te_plugin_install_blocked']
    ) {

        $notice = 'Installing and uploading new plugins are disabled.';
    }

    elseif (
        isset( $_GET['te_plugin_editor_blocked'] ) &&
        '1' === $_GET['te_plugin_editor_blocked']
    ) {

        $notice = 'Plugin editing is disabled.';
    }

    if ( ! empty( $notice ) ) {
        ?>
        <div class="notice notice-error is-dismissible">
            <p>
                <strong>TE Production Lock:</strong>
                <?php echo esc_html( $notice ); ?>
                Please contact the site administrator.
            </p>
        </div>
        <?php
    }
}
?>