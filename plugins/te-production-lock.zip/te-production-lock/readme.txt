this plugin specially designed to lock activities like
1. theme install, update, delete, activate
2. plugin install, update, delete, activate.

for more control it controls by user roles.