<?php
/**
 * Plugin Name: TE Production Lock
 * Description: Provides production environment restrictions and security controls for WordPress.
 * Version: 1.0.0
 * Author: TE
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Plugin Constants
 */
define( 'TE_PRODUCTION_LOCK_VERSION', '1.0.0' );
define( 'TE_PRODUCTION_LOCK_PATH', plugin_dir_path( __FILE__ ) );
define( 'TE_PRODUCTION_LOCK_URL', plugin_dir_url( __FILE__ ) );


/**
 * Load Theme Activation Lock Module
 */
require_once TE_PRODUCTION_LOCK_PATH . 'modules/theme-activation-lock.php';

require_once TE_PRODUCTION_LOCK_PATH . 'modules/plugin-lock.php';
