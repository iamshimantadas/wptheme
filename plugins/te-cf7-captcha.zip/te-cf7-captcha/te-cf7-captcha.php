<?php
/**
 * Plugin Name: TE CF7 Captcha
 * Plugin URI: 
 * Description: Text captcha for contact form 7 forms.
 * Version: 1.0.0
 * Author: techievolve team
 * Author URI: https://techievolve.com/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * 
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin Constants
 */
define( 'TE_CF7_CAPTCHA_PATH', plugin_dir_path( __FILE__ ) );
define( 'TE_CF7_CAPTCHA_URL', plugin_dir_url( __FILE__ ) );

/**
 * Load Modules
 */
require_once(TE_CF7_CAPTCHA_PATH . 'modules/' . 'text-captcha.php');

?>
