This plugin has been developed to fulfil the request of text-captcha problem for cf7 forms.
In general we use google recapctah or hcaptcha which sometime cost higher to use.
This plugin we can use as an alternative.