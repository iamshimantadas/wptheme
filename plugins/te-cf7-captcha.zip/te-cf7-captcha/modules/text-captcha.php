<?php
require_once(TE_CF7_CAPTCHA_PATH . 'vendor/autoload.php');

// require_once('vendor/autoload.php');

use Gregwar\Captcha\CaptchaBuilder;
use Gregwar\Captcha\PhraseBuilder;

/**
 * Start session.
 */
add_action( 'init', 'te_start_session', 1 );
function te_start_session() {
    if ( ! session_id() ) {
        session_start();
    }
}

/**
 * Register CF7 tag.
 */
add_action( 'wpcf7_init', 'te_register_text_captcha_tag' );
function te_register_text_captcha_tag() {
    wpcf7_add_form_tag(
        array( 'text_captcha', 'text_captcha*' ),
        'te_text_captcha_handler',
        array(
            'name-attr' => true,
        )
    );
}

/**
 * Render captcha field.
 */
function te_text_captcha_handler( $tag ) {
    $name = $tag->name;
    $phrase_builder = new PhraseBuilder(6,'ABCDEFGHJKLMNPQRSTUVWXYZ23456789');

    $builder = new CaptchaBuilder(
        null,
        $phrase_builder
    );

    $builder->build( 220, 60 );
    $_SESSION['text_captcha'] = $builder->getPhrase();

    ob_start();
    ?>

    <div class="te-captcha-wrap">
    <img class="te-captcha-image" src="<?php echo esc_attr( $builder->inline() ); ?>" alt="Captcha"/>

    <span class="dashicons dashicons-image-rotate te-refresh-captcha" aria-hidden="true"></span>

    <span class="wpcf7-form-control-wrap" data-name="<?php echo esc_attr( $name ); ?>">
        <br>            
        <input type="text" name="<?php echo esc_attr( $name ); ?>" value="" class="wpcf7-form-control wpcf7-text te-captcha-input" autocomplete="off" placeholder="Enter the captcha"/>
    </span>

</div>

    <?php

    return ob_get_clean();
}

/**
 * Validation hooks.
 */
add_filter(
    'wpcf7_validate_text_captcha',
    'te_validate_text_captcha',
    10,
    2
);

add_filter(
    'wpcf7_validate_text_captcha*',
    'te_validate_text_captcha',
    10,
    2
);

/**
 * Validate captcha.
 */
function te_validate_text_captcha( $result, $tag ) {

    $name = $tag->name;

    $submitted = isset( $_POST[ $name ] )
        ? sanitize_text_field( wp_unslash( $_POST[ $name ] ) )
        : '';

    $captcha = isset( $_SESSION['text_captcha'] )
        ? $_SESSION['text_captcha']
        : '';

    if ( empty( $submitted ) ) {

        $result->invalidate(
            $tag,
            __( 'Please enter the captcha code.', 'smart-form-tools-for-cf7' )
        );

        return $result;
    }

    if ( strtoupper( $submitted ) !== strtoupper( $captcha ) ) {

        $result->invalidate(
            $tag,
            __( 'Invalid captcha code.', 'smart-form-tools-for-cf7' )
        );

        return $result;
    }

    unset( $_SESSION['text_captcha'] );

    return $result;
}

/**
 * Refresh captcha AJAX.
 */
add_action(
    'wp_ajax_te_refresh_captcha',
    'te_refresh_captcha'
);

add_action(
    'wp_ajax_nopriv_te_refresh_captcha',
    'te_refresh_captcha'
);

function te_refresh_captcha() {

    check_ajax_referer(
        'te_captcha_nonce',
        'nonce'
    );

    $phrase_builder = new PhraseBuilder(
        6,
        'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    );

    $builder = new CaptchaBuilder(
        null,
        $phrase_builder
    );

    $builder->build( 220, 60 );

    $_SESSION['text_captcha'] = $builder->getPhrase();

    wp_send_json_success(
        array(
            'image' => $builder->inline(),
        )
    );
}

/**
 * Assets.
 */
add_action(
    'wp_enqueue_scripts',
    'te_captcha_assets'
);

function te_captcha_assets() {

    wp_enqueue_style( 'dashicons' );

    wp_register_script(
        'te-captcha',
        '',
        array( 'jquery' ),
        '1.0.0',
        true
    );

    wp_enqueue_script( 'te-captcha' );

    wp_localize_script(
        'te-captcha',
        'teCaptcha',
        array(
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'te_captcha_nonce' ),
        )
    );

    wp_add_inline_script(
        'te-captcha',
        "
        jQuery(document).on('click', '.te-refresh-captcha', function() {

            var wrapper = jQuery(this).closest('.te-captcha-wrap');

            jQuery.post(
                teCaptcha.ajaxurl,
                {
                    action: 'te_refresh_captcha',
                    nonce: teCaptcha.nonce
                },
                function(response) {

                    if (response.success) {
                        wrapper.find('.te-captcha-image')
                            .attr('src', response.data.image);
                    }
                }
            );

        });
        "
    );

    wp_register_style(
        'te-captcha-style',
        false,
        array(),
        '1.0.0'
    );

    wp_enqueue_style(
        'te-captcha-style'
    );

    wp_add_inline_style(
        'te-captcha-style',
        '
        .te-captcha-wrap{
            display:flex;
            align-items:center;
            gap:10px;
            flex-wrap:wrap;
        }

        .te-refresh-captcha{
            cursor:pointer;
            width:22px;
            height:22px;
            font-size:22px;
        }

        .te-captcha-input{
            min-width:180px;
        }
    '
    );
}

/**
 * Tag generator.
 */
add_action(
    'wpcf7_admin_init',
    'te_add_text_captcha_generator',
    55
);

function te_add_text_captcha_generator() {

    $tag_generator = WPCF7_TagGenerator::get_instance();

    $tag_generator->add(
        'text_captcha',
        'Text Captcha',
        'te_text_captcha_generator'
    );
}

function te_text_captcha_generator( $contact_form, $args ) {
    ?>
    <div class="control-box">
        <p><?php esc_html_e( 'Generates a text captcha field.', 'smart-form-tools-for-cf7' ); ?></p>
    </div>

    <footer class="insert-box">
        <input
            type="text"
            class="tag code"
            value="[text_captcha* captcha]"
            readonly
        />
    </footer>
    <?php
}